# Access to MySQL Converter - Production Edition

A production-ready web application for converting Microsoft Access databases (.accdb, .mdb) to MySQL databases with a modern, user-friendly interface.

## Features

✅ **Complete Database Migration**
- Upload and connect to Access databases
- Connect to MySQL databases
- View all tables and schemas
- Select specific tables for export
- Batch data transfer with progress tracking

✅ **Smart Data Handling**
- Automatic data type conversion
- Batch processing for large datasets
- Override existing data option
- Auto-create tables if they don't exist
- Data validation and error handling

✅ **Configuration Management**
- Save export configurations
- Load and reuse configurations
- Export/import configuration files
- Quick configuration switching

✅ **Data Preview**
- Preview Access table data
- Preview MySQL table data after export
- Real-time export progress
- Detailed export results

## Architecture

### Backend (Python/Flask)
- **Flask** - Web framework
- **pyodbc** - Access database connectivity
- **pymysql** - MySQL database connectivity
- **pandas** - Data processing and transfer
- **SQLAlchemy** - Optional ORM support

### Frontend
- Pure HTML/CSS/JavaScript
- Modern responsive design
- RESTful API integration
- Real-time progress updates

## Prerequisites

### Windows (for Access Database Support)
- Python 3.8 or higher
- Microsoft Access Database Engine (ODBC Driver)
  - Download: [Microsoft Access Database Engine 2016 Redistributable](https://www.microsoft.com/en-us/download/details.aspx?id=54920)
- MySQL Server 5.7 or higher

### Linux/Mac
- Python 3.8 or higher
- mdbtools (for Access database reading)
- MySQL Server 5.7 or higher

## Installation

### 1. Clone or Download the Project

```bash
cd access-to-mysql-converter
```

### 2. Install Python Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 3. Install Access ODBC Driver

**Windows:**
- Download and install [Microsoft Access Database Engine 2016 Redistributable](https://www.microsoft.com/en-us/download/details.aspx?id=54920)
- Choose the version matching your Python installation (32-bit or 64-bit)

**Linux:**
```bash
sudo apt-get update
sudo apt-get install mdbtools unixodbc unixodbc-dev
```

**Mac:**
```bash
brew install mdbtools
```

### 4. Configure Environment

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your settings
nano .env
```

### 5. Setup MySQL

Ensure MySQL is installed and running:

```bash
# Check MySQL status
sudo systemctl status mysql

# Start MySQL if not running
sudo systemctl start mysql

# Create a database (optional)
mysql -u root -p
CREATE DATABASE converted_db;
EXIT;
```

## Running the Application

### 1. Start the Backend Server

```bash
cd backend
python app.py
```

The backend will start on `http://localhost:5000`

### 2. Open the Frontend

Open `frontend/index.html` in your web browser, or serve it with a simple HTTP server:

```bash
cd frontend

# Using Python
python -m http.server 8000

# Using Node.js (if installed)
npx http-server -p 8000
```

Then navigate to `http://localhost:8000`

## Usage Guide

### Step 1: Connect to Databases

1. **Access Database (Source)**
   - Click "Choose File" and select your .accdb or .mdb file
   - Click "Upload & Connect"
   - Wait for the connection confirmation

2. **MySQL Database (Target)**
   - Enter MySQL host (default: localhost)
   - Enter port (default: 3306)
   - Enter username (default: root)
   - Enter password
   - Enter database name
   - Click "Connect to MySQL"

### Step 2: Select Tables

1. Click "Load Tables" to view all Access tables
2. Select the tables you want to export:
   - Click individual tables, or
   - Use "Select All" / "Deselect All" buttons

### Step 3: Configure Export Options

- **Override existing data**: Replaces data in MySQL tables if they exist
- **Create tables if they don't exist**: Automatically creates MySQL tables
- **Batch Size**: Number of rows to transfer per transaction (1000 recommended)

### Step 4: Export Data

1. Click "Start Export"
2. Monitor the progress bar
3. Review export results

### Step 5: Save Configuration (Optional)

1. Click "Save Configuration"
2. Enter a configuration name
3. The configuration will be saved for future use

### Step 6: View MySQL Data

1. Select a table from the dropdown
2. View the exported data in the preview pane

## API Documentation

### Endpoints

#### Health Check
```
GET /api/health
```

#### Upload Access File
```
POST /api/upload-access
Content-Type: multipart/form-data
Body: file (Access database file)
```

#### Connect to Access Database
```
POST /api/connect-access
Content-Type: application/json
Body: {
  "filepath": "path/to/database.accdb",
  "session_id": "session_123"
}
```

#### Connect to MySQL Database
```
POST /api/connect-mysql
Content-Type: application/json
Body: {
  "host": "localhost",
  "port": 3306,
  "user": "root",
  "password": "password",
  "database": "mydb",
  "session_id": "session_123"
}
```

#### Get Table Information
```
POST /api/get-table-info
Content-Type: application/json
Body: {
  "session_id": "session_123",
  "table_name": "Customers"
}
```

#### Preview Table Data
```
POST /api/preview-table
Content-Type: application/json
Body: {
  "session_id": "session_123",
  "table_name": "Customers",
  "source": "access",  // or "mysql"
  "limit": 100
}
```

#### Export Tables
```
POST /api/export
Content-Type: application/json
Body: {
  "session_id": "session_123",
  "tables": ["Customers", "Orders"],
  "options": {
    "override_data": true,
    "create_tables": true,
    "batch_size": 1000
  }
}
```

#### Save Configuration
```
POST /api/save-config
Content-Type: application/json
Body: {
  "config_name": "My Config",
  "config_data": { ... }
}
```

#### List Configurations
```
GET /api/list-configs
```

#### Load Configuration
```
GET /api/load-config/<config_id>
```

#### Delete Configuration
```
DELETE /api/delete-config/<config_id>
```

## Configuration Files

Saved configurations are stored in `configs/` as JSON files with the following structure:

```json
{
  "config_id": "abc123def456",
  "config_name": "My Export Config",
  "access_file": {
    "filename": "database.accdb",
    "filepath": "/path/to/database.accdb"
  },
  "tables": ["Customers", "Orders", "Products"],
  "mysql": {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "database": "converted_db"
  },
  "options": {
    "override_data": true,
    "create_tables": true,
    "batch_size": 1000
  },
  "created_at": "2024-02-16T10:30:00",
  "updated_at": "2024-02-16T10:30:00"
}
```

## Troubleshooting

### "No Access ODBC drivers found"

**Windows:**
- Install Microsoft Access Database Engine 2016 Redistributable
- Make sure the bit version (32/64) matches your Python installation

**Linux:**
```bash
sudo apt-get install mdbtools unixodbc
```

### "Failed to connect to MySQL"

- Verify MySQL is running: `sudo systemctl status mysql`
- Check credentials are correct
- Ensure database exists: `CREATE DATABASE yourdb;`
- Check firewall settings if connecting remotely

### "Access Denied" errors

- Verify MySQL user has proper permissions:
```sql
GRANT ALL PRIVILEGES ON database_name.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

### Upload size limits

- Default maximum file size is 100MB
- Modify in `backend/app.py`: `app.config['MAX_CONTENT_LENGTH']`

### Large tables export slowly

- Increase batch size (e.g., 5000)
- Export tables separately
- Optimize MySQL configuration for bulk inserts

## Production Deployment

### Using Gunicorn (Recommended)

```bash
cd backend
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Docker

```dockerfile
FROM python:3.9

WORKDIR /app
COPY backend/requirements.txt .
RUN pip install -r requirements.txt

COPY backend/ .
COPY configs/ ../configs/
COPY data/ ../data/

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

### Nginx Configuration

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        root /path/to/frontend;
        index index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Security Considerations

1. **Change default credentials** in production
2. **Use HTTPS** for production deployments
3. **Implement authentication** for multi-user environments
4. **Sanitize file uploads** - already implemented with filename sanitization
5. **Use environment variables** for sensitive configuration
6. **Limit file upload sizes** - already configured
7. **Implement rate limiting** for API endpoints
8. **Regular backups** of configurations and data

## Performance Tips

1. **Batch Size**: 1000-5000 rows optimal for most cases
2. **Table Indexes**: Create indexes after import for better performance
3. **MySQL Configuration**: Optimize `innodb_buffer_pool_size` for large imports
4. **Network**: Use local MySQL instance when possible
5. **Disable Constraints**: Temporarily disable foreign keys during import

## License

MIT License - Feel free to use and modify

## Support

For issues, questions, or contributions:
- Check the troubleshooting section
- Review the API documentation
- Check application logs in `logs/app.log`

## Version History

### v1.0.0 (Production)
- Initial production release
- Full Access to MySQL conversion
- Configuration management
- Data preview and validation
- Batch processing
- Error handling and logging

## Credits

Built with:
- Flask (Python web framework)
- PyODBC (Access connectivity)
- PyMySQL (MySQL connectivity)
- Pandas (Data processing)
