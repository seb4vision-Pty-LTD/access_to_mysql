const API_BASE = 'http://localhost:3000/api';

// State
let accessTables = [];
let selectedTables = [];
let mysqlConnected = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeEventListeners();
});

function initializeEventListeners() {
    // Access file upload
    document.getElementById('accessFileInput').addEventListener('change', handleAccessFileUpload);

    // MySQL form
    document.getElementById('mysqlForm').addEventListener('submit', handleMySQLConnect);

    // Export button
    document.getElementById('exportBtn').addEventListener('click', handleExport);

    // Save/Load config
    document.getElementById('saveConfigBtn').addEventListener('click', handleSaveConfig);
    document.getElementById('loadConfigBtn').addEventListener('click', handleLoadConfig);

    // MySQL viewer
    document.getElementById('refreshMySQLBtn').addEventListener('click', refreshMySQLTables);
    document.getElementById('mysqlTableSelect').addEventListener('change', handleMySQLTableSelect);
}

// Access Database Handling
async function handleAccessFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('accessFile', file);

    try {
        showToast('Uploading Access database...', 'info');
        
        const response = await fetch(`${API_BASE}/upload-access`, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            accessTables = data.tables;
            document.getElementById('accessFileName').textContent = `✓ ${data.filename}`;
            document.getElementById('accessTablesList').textContent = `${data.tables.length} tables found`;
            document.getElementById('accessStatus').classList.add('active');
            
            renderTableSelection();
            showToast('Access database loaded successfully!', 'success');
        } else {
            showToast('Error loading Access database: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error uploading file: ' + error.message, 'error');
    }
}

function renderTableSelection() {
    const container = document.getElementById('tablesSelection');
    
    if (accessTables.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <p>Upload an Access database to see available tables</p>
            </div>
        `;
        return;
    }

    container.innerHTML = accessTables.map(table => `
        <div class="table-checkbox" data-table="${table}">
            <input type="checkbox" id="table-${table}" value="${table}">
            <div class="table-info">
                <div class="table-name">${table}</div>
                <button class="btn btn-secondary" style="margin-top: 8px; padding: 4px 8px; font-size: 0.75rem;" onclick="previewTable('${table}')">
                    Preview
                </button>
            </div>
        </div>
    `).join('');

    // Add event listeners to checkboxes
    container.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', handleTableSelection);
    });

    // Add click event to table cards
    container.querySelectorAll('.table-checkbox').forEach(card => {
        card.addEventListener('click', (e) => {
            if (e.target.type !== 'checkbox' && e.target.tagName !== 'BUTTON') {
                const checkbox = card.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                handleTableSelection({ target: checkbox });
            }
        });
    });
}

function handleTableSelection(event) {
    const checkbox = event.target;
    const card = checkbox.closest('.table-checkbox');
    
    if (checkbox.checked) {
        card.classList.add('selected');
        if (!selectedTables.includes(checkbox.value)) {
            selectedTables.push(checkbox.value);
        }
    } else {
        card.classList.remove('selected');
        selectedTables = selectedTables.filter(t => t !== checkbox.value);
    }

    updateExportButton();
}

function updateExportButton() {
    const exportBtn = document.getElementById('exportBtn');
    exportBtn.disabled = selectedTables.length === 0 || !mysqlConnected;
    
    if (selectedTables.length > 0 && mysqlConnected) {
        exportBtn.textContent = `🚀 Export ${selectedTables.length} Table${selectedTables.length > 1 ? 's' : ''}`;
    } else {
        exportBtn.innerHTML = '<span class="btn-icon">🚀</span>Export Selected Tables';
    }
}

async function previewTable(tableName) {
    try {
        const response = await fetch(`${API_BASE}/preview-table`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tableName })
        });

        const data = await response.json();

        if (data.success) {
            displayTablePreview(tableName, data.columns, data.data, data.totalRows);
        } else {
            showToast('Error previewing table: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

function displayTablePreview(tableName, columns, data, totalRows) {
    const previewContainer = document.getElementById('tablePreview');
    const previewTableName = document.getElementById('previewTableName');
    const previewRowCount = document.getElementById('previewRowCount');
    const previewTable = document.getElementById('previewTable');

    previewTableName.textContent = tableName;
    previewRowCount.textContent = `${totalRows} rows (showing first 10)`;

    // Build table
    let tableHTML = '<thead><tr>';
    columns.forEach(col => {
        tableHTML += `<th>${col}</th>`;
    });
    tableHTML += '</tr></thead><tbody>';

    data.forEach(row => {
        tableHTML += '<tr>';
        columns.forEach(col => {
            let value = row[col];
            if (value === null || value === undefined) {
                value = '<span style="color: var(--color-text-muted);">NULL</span>';
            } else if (value instanceof Date) {
                value = value.toLocaleString();
            }
            tableHTML += `<td>${value}</td>`;
        });
        tableHTML += '</tr>';
    });

    tableHTML += '</tbody>';
    previewTable.innerHTML = tableHTML;
    previewContainer.classList.remove('hidden');

    // Scroll to preview
    previewContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// MySQL Connection
async function handleMySQLConnect(event) {
    event.preventDefault();

    const config = {
        host: document.getElementById('mysqlHost').value,
        user: document.getElementById('mysqlUser').value,
        password: document.getElementById('mysqlPassword').value,
        database: document.getElementById('mysqlDatabase').value
    };

    try {
        showToast('Connecting to MySQL...', 'info');

        const response = await fetch(`${API_BASE}/connect-mysql`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            mysqlConnected = true;
            document.getElementById('mysqlStatus').classList.add('active');
            showToast('Connected to MySQL successfully!', 'success');
            updateExportButton();
        } else {
            showToast('MySQL connection failed: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

// Export Tables
async function handleExport() {
    if (selectedTables.length === 0 || !mysqlConnected) return;

    const override = document.getElementById('overrideData').checked;
    const progressContainer = document.getElementById('exportProgress');
    const progressList = document.getElementById('progressList');

    progressContainer.classList.remove('hidden');
    progressList.innerHTML = '';

    try {
        showToast('Starting export...', 'info');

        const response = await fetch(`${API_BASE}/export-tables`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tables: selectedTables, override })
        });

        const data = await response.json();

        if (data.success) {
            data.results.forEach(result => {
                const statusClass = result.success ? 'success' : 'error';
                const statusText = result.success ? `✓ ${result.rowsExported} rows` : `✗ ${result.error}`;
                
                const progressItem = document.createElement('div');
                progressItem.className = `progress-item ${statusClass}`;
                progressItem.innerHTML = `
                    <span>${result.table}</span>
                    <span class="progress-status ${statusClass}">${statusText}</span>
                `;
                progressList.appendChild(progressItem);
            });

            const successCount = data.results.filter(r => r.success).length;
            showToast(`Export completed! ${successCount}/${data.results.length} tables exported successfully`, 'success');
            
            // Refresh MySQL tables
            await refreshMySQLTables();
        } else {
            showToast('Export failed: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

// MySQL Viewer
async function refreshMySQLTables() {
    if (!mysqlConnected) return;

    try {
        const response = await fetch(`${API_BASE}/mysql-tables`);
        const data = await response.json();

        if (data.success) {
            const select = document.getElementById('mysqlTableSelect');
            select.innerHTML = '<option value="">Select a table to view...</option>';
            
            data.tables.forEach(table => {
                const option = document.createElement('option');
                option.value = table;
                option.textContent = table;
                select.appendChild(option);
            });

            if (data.tables.length > 0) {
                document.getElementById('mysqlEmptyState').classList.add('hidden');
            }
        }
    } catch (error) {
        showToast('Error loading MySQL tables: ' + error.message, 'error');
    }
}

async function handleMySQLTableSelect(event) {
    const tableName = event.target.value;
    if (!tableName) {
        document.getElementById('mysqlTableView').classList.add('hidden');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/view-mysql-table`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tableName })
        });

        const data = await response.json();

        if (data.success) {
            displayMySQLTable(tableName, data.columns, data.data, data.totalRows);
        } else {
            showToast('Error loading table: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

function displayMySQLTable(tableName, columns, data, totalRows) {
    const tableView = document.getElementById('mysqlTableView');
    const tableNameElem = document.getElementById('mysqlTableName');
    const rowCountElem = document.getElementById('mysqlRowCount');
    const tableElem = document.getElementById('mysqlTable');

    tableNameElem.textContent = tableName;
    rowCountElem.textContent = `${totalRows} total rows (showing first 100)`;

    // Build table
    let tableHTML = '<thead><tr>';
    columns.forEach(col => {
        tableHTML += `<th>${col}</th>`;
    });
    tableHTML += '</tr></thead><tbody>';

    data.forEach(row => {
        tableHTML += '<tr>';
        columns.forEach(col => {
            let value = row[col];
            if (value === null || value === undefined) {
                value = '<span style="color: var(--color-text-muted);">NULL</span>';
            }
            tableHTML += `<td>${value}</td>`;
        });
        tableHTML += '</tr>';
    });

    tableHTML += '</tbody>';
    tableElem.innerHTML = tableHTML;
    tableView.classList.remove('hidden');
}

// Config Management
async function handleSaveConfig() {
    if (selectedTables.length === 0) {
        showToast('Please select tables before saving configuration', 'warning');
        return;
    }

    const config = {
        selectedTables: selectedTables,
        mysqlConfig: {
            host: document.getElementById('mysqlHost').value,
            user: document.getElementById('mysqlUser').value,
            database: document.getElementById('mysqlDatabase').value
        },
        override: document.getElementById('overrideData').checked,
        savedAt: new Date().toISOString()
    };

    try {
        const response = await fetch(`${API_BASE}/save-config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ config })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Configuration saved successfully!', 'success');
        } else {
            showToast('Error saving configuration: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

async function handleLoadConfig() {
    try {
        const response = await fetch(`${API_BASE}/list-configs`);
        const data = await response.json();

        if (data.success) {
            displayConfigModal(data.configs);
        } else {
            showToast('Error loading configurations: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

function displayConfigModal(configs) {
    const modal = document.getElementById('configModal');
    const configList = document.getElementById('configList');

    if (configs.length === 0) {
        configList.innerHTML = `
            <div class="empty-state">
                <p>No saved configurations found</p>
            </div>
        `;
    } else {
        configList.innerHTML = configs.map(config => `
            <div class="config-item" onclick="loadConfig('${config.filename}')">
                <div>
                    <div class="config-name">${config.filename}</div>
                    <div class="config-date">${new Date(config.created).toLocaleString()}</div>
                </div>
            </div>
        `).join('');
    }

    modal.classList.remove('hidden');
}

async function loadConfig(filename) {
    try {
        const response = await fetch(`${API_BASE}/load-config/${filename}`);
        const data = await response.json();

        if (data.success) {
            const config = data.config;

            // Apply MySQL config
            document.getElementById('mysqlHost').value = config.mysqlConfig.host;
            document.getElementById('mysqlUser').value = config.mysqlConfig.user;
            document.getElementById('mysqlDatabase').value = config.mysqlConfig.database;
            document.getElementById('overrideData').checked = config.override;

            // Select tables
            selectedTables = config.selectedTables;
            document.querySelectorAll('.table-checkbox input[type="checkbox"]').forEach(checkbox => {
                if (selectedTables.includes(checkbox.value)) {
                    checkbox.checked = true;
                    checkbox.closest('.table-checkbox').classList.add('selected');
                }
            });

            updateExportButton();
            closeConfigModal();
            showToast('Configuration loaded successfully!', 'success');
        } else {
            showToast('Error loading configuration: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error: ' + error.message, 'error');
    }
}

function closeConfigModal() {
    document.getElementById('configModal').classList.add('hidden');
}

// Toast Notifications
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastSlideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Close modal on background click
document.addEventListener('click', (e) => {
    const modal = document.getElementById('configModal');
    if (e.target === modal) {
        closeConfigModal();
    }
});
